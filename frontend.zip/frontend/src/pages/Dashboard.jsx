import React, { useState } from "react";
import "../styles/Dashboard.css";
import LiquidEther from "./LiquidEther";

function Dashboard() {
  const [prompt, setPrompt] = useState("");
  const [audioUrl, setAudioUrl] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      alert("Please enter a mood or style!");
      return;
    }

    setLoading(true);
    setAudioUrl(null);

    try {
      const response = await fetch("http://localhost:4000/generate-music", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mood: prompt }),
      });

      if (!response.ok) throw new Error("Error generating music");

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
    } catch (error) {
      console.error("Error:", error);
      alert("Something went wrong while generating music!");
    }

    setLoading(false);
  };

  return (
    <div className="dashboard-container">
      {/* LiquidEther background fixed */}
      <LiquidEther
        colors={["#5227FF", "#FF9FFC", "#B19EEF"]}
        mouseForce={20}
        cursorSize={100}
        isViscous={false}
        viscous={30}
        iterationsViscous={32}
        iterationsPoisson={32}
        resolution={0.5}
        isBounce={false}
        autoDemo={true}
        autoSpeed={0.5}
        autoIntensity={2.2}
        takeoverDuration={0.25}
        autoResumeDelay={3000}
        autoRampDuration={0.6}
        style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", zIndex: 0 }}
      />

      {/* Dashboard content on top */}
      <div className="dashboard-content">
        <div className="music-card">
          <h1 className="title">AI Music Generator</h1>
          <p className="subtitle">
            Enter a mood or genre (e.g., “Calm Piano”, “Energetic Rock”) and
            generate a 20-second AI-composed track.
          </p>

          <div className="input-group">
            <input
              type="text"
              className="prompt-input"
              placeholder="Enter mood or genre..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
            <button
              onClick={handleGenerate}
              className="btn-primary"
              disabled={loading}
            >
              {loading ? "Generating..." : "Generate Music"}
            </button>
          </div>

          {audioUrl && (
            <div className="audio-section">
              <h3 className="result-title">Your Generated Music</h3>
              <audio controls src={audioUrl} className="audio-player"></audio>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
