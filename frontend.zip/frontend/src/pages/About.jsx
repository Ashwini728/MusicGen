import "../styles/About.css";

function About() {
  return (
    <section className="about">
      <h2 className="about-title">About Whispers of the Wires</h2>

      <p>
        <strong>Whispers of the Wires</strong> is an AI-powered music composition
        system designed to generate personalized tracks based on your moods, contexts,
        and preferences. By combining deep learning, natural language models, and
        advanced audio synthesis, it transforms emotions into meaningful melodies.
      </p>

      <p>
        The platform blends innovation in <strong>AI</strong>, <strong>music theory</strong>, 
        and <strong>user experience design</strong>. Whether it’s for relaxation, study,
        or creativity, it empowers you to co-create music with AI while offering
        real-time playback, visualization, and intuitive controls.
      </p>

      <hr />

      <p>
        Built with a modern <strong>React frontend</strong> and a 
        <strong> Python backend</strong>, <em>Whispers of the Wires</em> demonstrates
        how technology and artistry can merge into a seamless, interactive,
        and professional platform for AI-generated music.
      </p>

      <div className="about-cta">
        <a href="/dashboard">Try It Now</a>
      </div>
    </section>
  );
}

export default About;
