import "../styles/WaveformVisualizer.css";

function WaveformVisualizer() {
  return (
    <div className="music-card">
      <h3 className="section-title">Waveform / Spectrogram</h3>
      <div className="waveform-box">[Waveform Visualization Placeholder]</div>
    </div>
  );
}

export default WaveformVisualizer;
